<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Форма проверки</title>
</head>
<body>
    <!-- Форма для ввода данных пользователя -->
    <form id="userForm">
        <input type="text" id="name" placeholder="Имя"> <!-- Поле ввода имени -->
        <input type="email" id="email" placeholder="Email"> <!-- Поле ввода email -->
        <input type="number" id="age" placeholder="Возраст"> <!-- Поле ввода возраста -->
        <input type="text" id="specialty" placeholder="Специальность"> <!-- Поле ввода специальности -->
        <input type="number" id="experience" placeholder="Стаж работы (лет)"> <!-- Поле ввода стажа работы -->
        <div class="error" id="error"></div> <!-- Блок для отображения ошибок -->
        <button type="button" id="submitBtn">Отправить</button> <!-- Кнопка для отправки формы -->
    </form>

    <script>
        // Добавляем обработчик события на кнопку "Отправить"
        document.getElementById('submitBtn').addEventListener('click', function () {
            // Получаем значения полей и удаляем пробелы в начале и конце строк
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const age = parseInt(document.getElementById('age').value.trim()); // Преобразуем в число
            const specialty = document.getElementById('specialty').value.trim();
            const experience = document.getElementById('experience').value.trim();
            const errorDiv = document.getElementById('error'); // Блок для вывода ошибок
            errorDiv.textContent = ''; // Очищаем ошибки перед проверкой

            // Проверяем, заполнены ли все поля
            if (!name || !email || !age || !specialty || !experience) {
                errorDiv.textContent = 'Все поля должны быть заполнены.';
                return; // Прекращаем выполнение функции
            }

            // Проверяем возраст (должен быть больше 30 лет)
            if (age <= 30) {
                errorDiv.textContent = 'Возраст должен быть больше 30 лет.';
                return;
            }

            // Создаем объект с данными формы
            const formData = {
                name: name,
                email: email,
                age: age,
                specialty: specialty,
                experience: experience
            };

            // Создаем AJAX-запрос
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'saveData.php', true); // Отправка данных на сервер в файл saveData.php
            xhr.setRequestHeader('Content-Type', 'application/json'); // Указываем, что отправляем JSON

            // Обработчик ответа от сервера
            xhr.onload = function () {
                if (xhr.status === 200) { // Если сервер успешно обработал запрос
                    const response = JSON.parse(xhr.responseText); // Преобразуем ответ в объект
                    if (response.status === 'success') {
                        alert('Данные успешно отправлены!'); // Показываем сообщение об успехе
                    } else {
                        alert('Ошибка: данные не сохранены.'); // Ошибка сохранения
                    }
                } else {
                    alert('Ошибка при отправке данных.'); // Ошибка соединения
                }
            };

            // Отправляем JSON-объект с данными на сервер
            xhr.send(JSON.stringify(formData));
        });
    </script>
</body>
</html>
