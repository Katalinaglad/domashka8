<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Форма проверки</title>
</head>
<body>
    <form id="userForm">
        <input type="text" id="name" placeholder="Имя">
        <input type="email" id="email" placeholder="Email">
        <input type="number" id="age" placeholder="Возраст">
        <input type="text" id="specialty" placeholder="Специальность">
        <input type="number" id="experience" placeholder="Стаж работы (лет)">
        <div class="error" id="error"></div>
        <button type="button" id="submitBtn">Отправить</button>
    </form>
    <script>
        document.getElementById('submitBtn').addEventListener('click', function () {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const age = parseInt(document.getElementById('age').value.trim());
            const specialty = document.getElementById('specialty').value.trim();
            const experience = document.getElementById('experience').value.trim();
            const errorDiv = document.getElementById('error');
            errorDiv.textContent = '';

            if (!name || !email || !age || !specialty || !experience) {
                errorDiv.textContent = 'Все поля должны быть заполнены.';
                return;
            }

            if (age <= 30) {
                errorDiv.textContent = 'Возраст должен быть больше 30 лет.';
                return;
            }

            const formData = {
                name: name,
                email: email,
                age: age,
                specialty: specialty,
                experience: experience
            };
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'saveData.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');

            xhr.onload = function () {
                if (xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        alert('Данные успешно отправлены!');
                    } else {
                        alert('Ошибка: данные не сохранены.');
                    }
                } else {
                    alert('Ошибка при отправке данных.');
                }
            };

            xhr.send(JSON.stringify(formData));
        });
    </script>
</body>
</html>
