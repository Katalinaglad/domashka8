<?php

// Получаем JSON-данные из тела запроса и декодируем их в массив
$data = json_decode(file_get_contents('php://input'), true);

// Проверяем, есть ли данные
if ($data) {
    // Формируем строку с данными пользователя в удобном формате
    $line = "Имя: {$data['name']}, Email: {$data['email']}, Возраст: {$data['age']}, Специальность: {$data['specialty']}, Стаж: {$data['experience']} лет\n";

    // Записываем данные в файл 'data.txt', добавляя в конец файла (режим FILE_APPEND)
    file_put_contents('data.txt', $line, FILE_APPEND);

    // Отправляем JSON-ответ о успешном сохранении
    echo json_encode(['status' => 'success']);
} else {
    // Если данные не получены, отправляем JSON-ответ об ошибке
    echo json_encode(['status' => 'error']);
}

?>
