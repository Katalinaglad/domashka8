<?php

$data = json_decode(file_get_contents('php://input'), true);

if ($data) {
    $line = "Имя: {$data['name']}, Email: {$data['email']}, Возраст: {$data['age']}, Специальность: {$data['specialty']}, Стаж: {$data['experience']} лет\n";
    file_put_contents('data.txt', $line, FILE_APPEND);
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error']);
}
?>